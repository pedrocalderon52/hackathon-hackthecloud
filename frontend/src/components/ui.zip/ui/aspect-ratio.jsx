import { Root as AspectRatio } from "@radix-ui/react-aspect-ratio";

export { AspectRatio };
